#include <stdio.h>
#include <stdlib.h>
void swap(int *a, int *b);
void mergesorted(int *a, int start, int end, int mid);

void mergesort(int *a, int start, int end);
int max_wins(int *A, int k, int m, int j);
