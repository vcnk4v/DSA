#include <stdio.h>

int cmp(long long int *a_arr1, long long int *a_arr2, long long int *b_arr1, long long int *b_arr2, int i1, int i2);
void mergesorted(long long int *a, int start, int end, int mid, long long int *b);
void mergesort(long long int *a, int start, int end, long long int *b);
long long int j2_end(long long int *b, long long int *a, int n);
