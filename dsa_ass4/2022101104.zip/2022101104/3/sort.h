#include <stdio.h>
#include <stdlib.h>

int compare(char *a, char *b);
void mergesorted(char **a, int start, int end, int mid, int max);
void mergesort(char **a, int start, int end, int max);
